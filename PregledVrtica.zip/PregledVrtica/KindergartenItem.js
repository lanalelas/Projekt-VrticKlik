// components/KindergartenItem.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const KindergartenItem = ({ kindergarten }) => {
  return (
    <View style={styles.card}>
      <Text style={styles.name}>{kindergarten.name}</Text>
      <Text style={styles.location}>Location: {kindergarten.location}</Text>
      <Text style={styles.contact}>Contact: {kindergarten.contact}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 16,
    marginBottom: 16,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2,
  },
  name: { fontSize: 18, fontWeight: 'bold' },
  location: { fontSize: 16 },
  contact: { fontSize: 14, color: 'gray' },
});

export default KindergartenItem;

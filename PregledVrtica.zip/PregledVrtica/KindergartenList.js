// components/KindergartenList.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import KindergartenItem from './KindergartenItem';

const KindergartenList = () => {
  const [kindergartens, setKindergartens] = useState([]);

  useEffect(() => {
    const fetchKindergartens = async () => {
      const querySnapshot = await getDocs(collection(db, 'kindergartens'));
      const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setKindergartens(data);
    };
    fetchKindergartens();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Kindergartens in the Country</Text>
      <FlatList
        data={kindergartens}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <KindergartenItem kindergarten={item} />}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 16 },
});

export default KindergartenList;

document.getElementById('kindergarten-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const name = document.getElementById('kindergarten-name').value;
    const address = document.getElementById('kindergarten-address').value;
    const city = document.getElementById('kindergarten-city').value;
    const workingHours = document.getElementById('kindergarten-working-hours').value;
    const childrenCount = document.getElementById('kindergarten-children-count').value;
    const price = document.getElementById('kindergarten-price').value;
    const phone = document.getElementById('kindergarten-phone').value;
    const type = document.getElementById('kindergarten-type').value;
    const picture = document.getElementById('kindergarten-picture').files[0];

    // Validate required fields
    if (!name || !address || !city || !phone || !type || !picture) {
        alert('Please fill in all required fields.');
        return;
    }

    // Create a FormData object to send the file
    const formData = new FormData();
    formData.append('picture', picture);

    // Upload the image to the server
    fetch('http://localhost:3000/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const kindergartens = JSON.parse(localStorage.getItem('kindergartens')) || [];
        kindergartens.push({
            name,
            address,
            city,
            workingHours,
            childrenCount,
            price,
            phone,
            type,
            picture: data.url // Use the URL returned from the server
        });
        localStorage.setItem('kindergartens', JSON.stringify(kindergartens));
        window.location.href = 'index.html'; // Redirect to main page
    })
    .catch(error => {
        console.error('Error uploading the image:', error);
        alert('Failed to upload the image. Please try again later.');
    });
});
// Function to display kindergartens
function displayKindergartens(kindergartens = null) {
  const list = document.getElementById("kindergarten-list");
  const allKindergartens =
    kindergartens || JSON.parse(localStorage.getItem("kindergartens")) || [];
  list.innerHTML = "";

  // If no kindergartens match the criteria
  if (allKindergartens.length === 0) {
    const noResultsMessage = document.createElement("p");
    noResultsMessage.textContent = "No kindergartens match the criteria.";
    list.appendChild(noResultsMessage);
    return;
  }

  // Display each kindergarten
  allKindergartens.forEach((k, index) => {
    const li = document.createElement("li");
    li.className = "kindergarten-list-item"; // Add a class for styling the list item

    // Create an item container to hold the image and text (using flexbox)
    const kindergartenItem = document.createElement("div");
    kindergartenItem.className = "kindergarten-item"; // Styling class for flexbox layout

    // Create the image element
    const image = document.createElement("img");
    image.src = k.picture; // Use the URL stored in localStorage for the image
    image.alt = `${k.name} image`;
    image.className = "kindergarten-image"; // Add a class to the image for styling

    // Create the text content for the kindergarten
    const textContent = document.createElement("div");
    textContent.className = "kindergarten-text";

    const name = document.createElement("h3");
    name.textContent = k.name; // Kindergarten name

    const address = document.createElement("p");
    address.textContent = `Address: ${k.address}, ${k.city || "Not specified"}`; // Address and city

    const price = document.createElement("p");
    price.textContent = `Price: €${k.price}`; // Price

    const childrenCount = document.createElement("p");
    childrenCount.textContent = `Children count: ${k.childrenCount}`; // Number of children

    // Create the link to the detailed page
    const detailsLink = document.createElement("a");
    detailsLink.href = `kindergarten_details.html?name=${encodeURIComponent(
      k.name
    )}`; // Details page URL
    detailsLink.textContent = "View details";
    detailsLink.className = "view-details-link"; // Styling class for the link

    // Append all the text elements to the text container
    textContent.appendChild(name);
    textContent.appendChild(address);
    textContent.appendChild(price);
    textContent.appendChild(childrenCount);
    textContent.appendChild(detailsLink);

    // Append the image and text container to the item container
    kindergartenItem.appendChild(image);
    kindergartenItem.appendChild(textContent);

    // Append the item container to the list item
    li.appendChild(kindergartenItem);

    // Create the delete icon
    const deleteIcon = document.createElement("i");
    deleteIcon.className = "fas fa-trash-alt";
    deleteIcon.style.marginLeft = "10px";
    deleteIcon.style.cursor = "pointer";
    deleteIcon.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (confirm(`Are you sure you want to delete ${k.name}?`)) {
        const kindergartens =
          JSON.parse(localStorage.getItem("kindergartens")) || [];
        kindergartens.splice(index, 1);
        localStorage.setItem("kindergartens", JSON.stringify(kindergartens));
        displayKindergartens(); // Update the list based on the current filter
      }
    });

    // Append delete icon to the list item
    li.appendChild(deleteIcon);

    // Append the list item to the list
    list.appendChild(li);
  });
}

function applyFilter() {
  const minPrice = parseFloat(document.getElementById("min-price").value) || 0;
  const maxPrice =
    parseFloat(document.getElementById("max-price").value) || Infinity;
  const location = document
    .getElementById("location-filter")
    .value.trim()
    .toLowerCase();
  const type = document.getElementById("type-filter").value.trim().toLowerCase(); // Normalize type value

  const kindergartens = JSON.parse(localStorage.getItem("kindergartens")) || [];

  if (kindergartens.length === 0) {
    console.error("No kindergartens available for filtering.");
    displayKindergartens();
    return;
  }

  console.log("Applying filters...");
  console.log(`Min Price: ${minPrice}, Max Price: ${maxPrice}`);
  console.log(`Location: ${location}`);
  console.log(`Type: ${type}`);

  // Filtracija prema svim kriterijima
  const filteredKindergartens = kindergartens.filter((k) => {
    const isWithinPriceRange = k.price >= minPrice && k.price <= maxPrice;
    const matchesLocation = location
      ? k.city.toLowerCase().includes(location)
      : true;
    const matchesType = type ? k.type.toLowerCase() === type : true; // Match type (case insensitive)

    // Log individual checks for debugging
    console.log(
      `Kindergarten: ${k.name}, Price Match: ${isWithinPriceRange}, Location Match: ${matchesLocation}, Type Match: ${matchesType}`
    );

    return isWithinPriceRange && matchesLocation && matchesType;
  });

  console.log("Filtered Kindergartens: ", filteredKindergartens);
  displayKindergartens(filteredKindergartens);
}


// Function to handle the search
function searchKindergartens() {
  const searchTerm = document.getElementById("search").value.toLowerCase();
  const kindergartens = JSON.parse(localStorage.getItem("kindergartens")) || []; // Retrieve kindergartens from localStorage

  const filteredKindergartens = kindergartens.filter((k) =>
    k.name.toLowerCase().includes(searchTerm)
  ); // Filter based on the search term

  displayKindergartens(filteredKindergartens); // Pass the filtered kindergartens to the display function
}

// Pokretanje aplikacije
window.onload = () => {
  console.log("Initializing app...");

  displayKindergartens();
};
